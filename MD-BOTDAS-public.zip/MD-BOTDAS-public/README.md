## OSCAR-MD-V6

<p align="center">

  <img src="http://readme-typing-svg.herokuapp.com?color=%230B80F7&center=true&vCenter=true&multiline=false&lines=WELCOME;My+name+is+JAROT-OFFC;IKUTIN-SOSIALMEDIA+SAYA!!;JANGAN+LUPA+JOIN+GROUP%2C++Bwang+%3A);jangan+lupa+kasih+start+!" alt="budii">

</p>
<div align="center">
  <p align="center">
<img src="https://telegra.ph/file/c6f6d447f2c76e3795a10.jpg" alt="Img" width="128" height="128"/>
</p>
 <p align="center">
<a href="#"><img title="JAROT OFFC" src="https://img.shields.io/badge/JAROT%20OFFC-red?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
  <p align="center">
<a href="https://wa.me/6285850539404"><img title="Author" src="https://img.shields.io/badge/Author-JAROT OFFC/JulieMwol?color=blue&style=for-the-badge&logo=whatsapp"></a>
<a href="https://youtube.com/channel/UCW7iXlE7TgvJMIXQck4NYBQ"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Jarot Offc/JulieMwol?color=blue&style=for-the-badge&logo=Youtube"></a>
<a href="https://instagram.com/Jarotr_"><img title="Instagram" src="https://img.shields.io/badge/Instagram-Jarot Offc/JulieMwol?color=blue&style=for-the-badge&logo=Instagram"></a>
<a href="https://chat.whatsapp.com/KGuKY4wuKHS8sj6K5IHjFG"><img title="Group Jarot offc" src="https://img.shields.io/badge/Group-Jarot Offc/JulieMwol?color=blue&style=for-the-badge&logo=WhatsApp"></a>
</p>
</div>
<p align="center">
Project created by <a href="https://github.com/JarotOffc">JAROT OFFC</a> to make it public
    <br>
       | © |
        Reserved |
    <br> 
</p>

---

## `Requirements`

- [Node.js](https://nodejs.org/en/)
- [Git](https://git-scm.com/downloads)
- [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip)
- [Libwebp](https://developers.google.com/speed/webp/download)
- Any text editor

## `Clone Repo & Installation dependencies`

```bash
git clone https://github.com/JarotOffc/oscar-md-v6.git
cd oscar-md-v6

npm start
```

## `For Termux/Ssh/Ubuntu`

```bash
pkg update && pkg upgrade
pkg install bash
pkg install libwebp
pkg install git -y
pkg install nodejs -y
pkg install ffmpeg -y
pkg install wget
pkg install imagemagick -y
git clone https://github.com/JarotOffc/oscar-md-v6
cd oscar-md-v6
npm start
```

## `For VPS (ubuntu)`

```bash
apt-get update && apt-get upgrade
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash - &&\
sudo apt-get install -y nodejs
apt install git
apt install ffmpeg -y
apt install libwebp
apt install imagemagick -y
apt-get install tesseract-ocr -y
apt install bash
git clone https://github.com/dasx000/bot-das.git bot
cd bot
npm install -g npm@9.2.0
npm i pm2 -g
npm start
```

## Stats

![Dasx000 GitHub stats](https://github-readme-stats.vercel.app/api?username=dasx000&show_icons=true&theme=radical)

<p align="center"><a href="https://github.com/dasx000"><img src="https://github-readme-stats.vercel.app/api/top-langs/?username=dasx000&theme=radical&layout=compact"></a></p>

<img alt="JavaScript" src="https://img.shields.io/badge/javascript%20-%23323330.svg?&style=for-the-badge&logo=javascript&logoColor=%23F7DF1E"/>

---
